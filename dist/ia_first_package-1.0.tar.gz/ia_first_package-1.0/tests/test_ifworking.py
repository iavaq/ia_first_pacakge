from ia_first_package.lib import try_me

def test_ifworking():
    assert len(try_me()) != 0